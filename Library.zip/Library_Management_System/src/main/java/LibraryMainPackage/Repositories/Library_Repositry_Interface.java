package LibraryMainPackage.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import LibraryMainPackage.Entities.Library;

public interface Library_Repositry_Interface extends JpaRepository<Library, Long>{

}
